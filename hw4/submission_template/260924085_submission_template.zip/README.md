hw4 - ip_address.txt, jupyter.log
to login to bokeh application: http://<ipaddress>:8080/nyc_dash?username=nyc&password=iheartnyc