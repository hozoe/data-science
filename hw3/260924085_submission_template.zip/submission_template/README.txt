The main function in dialog_analysis gets the input csv file from the data subdirectory, 
and writes the output to output.json in the root directory.
python3 -m unittest passes for all 3 tests.
submission_wrapper does not work, but the files should be zipped accordingly to their subdirectories following the instructions given.