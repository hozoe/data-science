the command line to log into the database only works with specifying the port, i.e.
mariadb -u comp598_grader -p -h INSTANCE_IP -P 6002
