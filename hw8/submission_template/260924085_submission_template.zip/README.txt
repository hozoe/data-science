hi TA sorry i didnt have time to fix the substrings of stopwords so the word counts esp for applejack are f-ed up lol :/// but it shouldnt affect the results too much (if its based on the ponies dialogs only, 
i understand it would be a huge mistake if i had to run the process on other data files)
also when you run compile_word_counts "compile_word_counts.py:23: FutureWarning: The default value of regex will change from True to False in a future version.
  df['dialog'] = df['dialog'].str.replace('[^\w\s]',' ')" is printed to stderr but it works fine i swear, wouldve totally perfected the functions if i had enough time:(

